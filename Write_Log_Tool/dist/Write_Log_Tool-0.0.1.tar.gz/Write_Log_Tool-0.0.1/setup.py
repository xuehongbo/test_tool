from setuptools import setup, find_packages

setup(
    name='Write_Log_Tool',
    version='0.0.1',
    keywords='write log',
    description='a write log tool',
    license='MIT License',
    url='https://github.com/xuehongbo/test_tool',
    author='HongBo Xue',
    author_email='505386086@qq.com',
    packages=find_packages(),
    platforms='any',
    install_requires=[],
)
