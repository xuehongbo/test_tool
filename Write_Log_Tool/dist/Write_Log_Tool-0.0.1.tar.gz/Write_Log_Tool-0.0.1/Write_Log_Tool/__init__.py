# coding:utf-8

from .write_log import Log
