from setuptools import setup, find_packages

setup(
    name='write_log_tool',
    version='0.0.1',
    keywords='write log',
    description='a write log tool',
    license='MIT License',
    url='https://github.com/xuehongbo/excel_driver',
    author='HongBo Xue',
    author_email='505386086@qq.com',
    packages=find_packages(),
    platforms='any',
    install_requires=[],
)
